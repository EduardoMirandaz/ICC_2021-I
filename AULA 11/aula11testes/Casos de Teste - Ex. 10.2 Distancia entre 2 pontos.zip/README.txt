Arquivo zip gerado em: 09/06/2021 20:55:36 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Ex. 10.2 Distância entre 2 pontos